#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/baileys"
BACKUP_DIR="/var/backups/baileys"
TIMESTAMP="$(date +%F_%H%M%S)"
ARCHIVE="$BACKUP_DIR/baileys_auth_info_$TIMESTAMP.tar.gz"

mkdir -p "$BACKUP_DIR"
chown root:root "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

echo "[backup] Archiving baileys_auth_info and tmp"
tar -czf "$ARCHIVE" -C "$APP_DIR" --warning=no-file-changed \
  baileys_auth_info tmp || echo "[backup] Warning: some paths missing"

# keep 14 days
find "$BACKUP_DIR" -type f -name "baileys_auth_info_*.tar.gz" -mtime +14 -delete || true

echo "[backup] Done: $ARCHIVE"
