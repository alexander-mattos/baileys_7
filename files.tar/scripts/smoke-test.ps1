Param(
    [string]$AdminToken = $env:ADMIN_TOKEN
)

Write-Host "Running smoke tests..."

Write-Host "1) TypeScript check"
npx tsc --noEmit
if ($LASTEXITCODE -ne 0) { throw "TypeScript check failed" }

Write-Host "2) Build (tsc -p tsconfig.server.json)"
npx tsc -p tsconfig.server.json
if ($LASTEXITCODE -ne 0) { throw "Build failed" }

Write-Host "3) Start server in background (node lib/server.js)"
$proc = Start-Process -FilePath node -ArgumentList 'lib/server.js' -PassThru
Start-Sleep -Seconds 2

Write-Host "4) Check /status"
$headers = @{}
if ($AdminToken) { $headers.Add('Authorization', "Bearer $AdminToken") }
$res = Invoke-RestMethod -Uri http://localhost:3333/status -Method GET -Headers $headers -ErrorAction Stop
Write-Host "Status: " ($res | ConvertTo-Json -Depth 3)

Write-Host "5) Stop server"
Stop-Process -Id $proc.Id -Force

Write-Host "Smoke tests completed"
